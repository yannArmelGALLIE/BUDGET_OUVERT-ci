// lib/services/auth_service.dart
// Gère l'authentification citoyen (login par email/mot de passe)
// et la persistance de la session via SharedPreferences.

import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/citoyen_model.dart';

class AuthService {
  static const String _baseUrl = 'https://api.budgetouvert.ci';
  static const String _keyToken = 'auth_token';
  static const String _keyCitoyen = 'citoyen_data';

  // ─── ÉTAT SESSION ────────────────────────────────────────────────────────
  static CitoyenModel? _currentCitoyen;

  static CitoyenModel? get currentCitoyen => _currentCitoyen;
  static bool get isLoggedIn => _currentCitoyen != null;

  // ─── INITIALISATION — à appeler au démarrage ─────────────────────────────
  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyCitoyen);
    if (raw != null) {
      try {
        _currentCitoyen = CitoyenModel.fromJson(json.decode(raw));
      } catch (_) {
        await prefs.remove(_keyCitoyen);
        await prefs.remove(_keyToken);
      }
    }
  }

  // ─── INSCRIPTION ─────────────────────────────────────────────────────────
  static Future<CitoyenModel> inscrire({
    required String nom,
    required String prenom,
    required String email,
    required String motDePasse,
    String? telephone,
    String? communeId,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse('$_baseUrl/citoyens/inscription'),
            headers: {'Content-Type': 'application/json'},
            body: json.encode({
              'nom': nom,
              'prenom': prenom,
              'email': email,
              'mot_de_passe': motDePasse,
              'telephone': telephone,
            }),
          )
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 201) {
        final data = json.decode(response.body) as Map<String, dynamic>;
        final citoyen = CitoyenModel.fromJson(data);
        await _persisterSession(citoyen);
        return citoyen;
      } else {
        final err = json.decode(response.body);
        throw Exception(
            err['message'] ?? 'Erreur inscription ${response.statusCode}');
      }
    } catch (e) {
      if (kDebugMode) print('AuthService.inscrire: $e');
      rethrow;
    }
  }

  // ─── CONNEXION ────────────────────────────────────────────────────────────
  static Future<CitoyenModel> connecter({
    required String email,
    required String motDePasse,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse('$_baseUrl/citoyens/connexion'),
            headers: {'Content-Type': 'application/json'},
            body: json.encode({
              'email': email,
              'mot_de_passe': motDePasse,
            }),
          )
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = json.decode(response.body) as Map<String, dynamic>;
        final citoyen = CitoyenModel.fromJson(data);
        await _persisterSession(citoyen);
        return citoyen;
      } else {
        final err = json.decode(response.body);
        throw Exception(err['message'] ?? 'Email ou mot de passe incorrect');
      }
    } catch (e) {
      if (kDebugMode) print('AuthService.connecter: $e');
      rethrow;
    }
  }

  // ─── DÉCONNEXION ─────────────────────────────────────────────────────────
  static Future<void> deconnecter() async {
    _currentCitoyen = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyToken);
    await prefs.remove(_keyCitoyen);
  }

  // ─── PERSISTANCE ─────────────────────────────────────────────────────────
  static Future<void> _persisterSession(CitoyenModel citoyen) async {
    _currentCitoyen = citoyen;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyToken, citoyen.token);
    await prefs.setString(_keyCitoyen, json.encode(citoyen.toJson()));
  }

  // ─── HEADER AUTH ─────────────────────────────────────────────────────────
  static Map<String, String> get authHeaders => {
        'Content-Type': 'application/json',
        if (_currentCitoyen != null)
          'Authorization': 'Bearer ${_currentCitoyen!.token}',
      };
}
