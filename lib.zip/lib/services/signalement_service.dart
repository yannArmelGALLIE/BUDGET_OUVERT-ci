// lib/services/signalement_service.dart
// Appels API pour créer un signalement et consulter les signalements du citoyen.

import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../models/signalement_model.dart';
import 'auth_service.dart';

class SignalementService {
  static const String _baseUrl = 'https://api.budgetouvert.ci';

  // ─── CRÉER UN SIGNALEMENT ─────────────────────────────────────────────────
  static Future<SignalementModel> creerSignalement({
    required String transactionId,
    required TypeSignalement type,
    required String commentaire,
    List<File> preuves = const [],
  }) async {
    try {
      // 1. Upload éventuel des preuves
      final List<String> preuvesUrls = [];
      for (final fichier in preuves) {
        final url = await _uploadFichier(fichier);
        preuvesUrls.add(url);
      }

      // 2. Création du signalement
      final response = await http
          .post(
            Uri.parse('$_baseUrl/signalements'),
            headers: AuthService.authHeaders,
            body: json.encode({
              'transaction_id': transactionId,
              'type': type.name,
              'commentaire': commentaire,
              'preuves': preuvesUrls,
            }),
          )
          .timeout(const Duration(seconds: 20));

      if (response.statusCode == 201) {
        final data = json.decode(response.body) as Map<String, dynamic>;
        return SignalementModel.fromJson(data);
      } else {
        final err = json.decode(response.body);
        throw Exception(err['message'] ?? 'Erreur ${response.statusCode}');
      }
    } catch (e) {
      if (kDebugMode) print('SignalementService.creerSignalement: $e');
      rethrow;
    }
  }

  // ─── SIGNALEMENTS DU CITOYEN CONNECTÉ ────────────────────────────────────
  static Future<List<SignalementModel>> mesSignalements() async {
    try {
      final response = await http
          .get(
            Uri.parse('$_baseUrl/signalements/mes-signalements'),
            headers: AuthService.authHeaders,
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((j) => SignalementModel.fromJson(j)).toList();
      } else {
        throw Exception('Erreur ${response.statusCode}');
      }
    } catch (e) {
      if (kDebugMode) print('SignalementService.mesSignalements: $e');
      rethrow;
    }
  }

  // ─── SIGNALEMENTS D'UNE TRANSACTION (lecture publique) ───────────────────
  static Future<List<SignalementModel>> signalementsDeLaTransaction(
      String transactionId) async {
    try {
      final response = await http
          .get(
            Uri.parse('$_baseUrl/transactions/$transactionId/signalements'),
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((j) => SignalementModel.fromJson(j)).toList();
      } else {
        throw Exception('Erreur ${response.statusCode}');
      }
    } catch (e) {
      if (kDebugMode) print('SignalementService.signalementsDeLaTransaction: $e');
      rethrow;
    }
  }

  // ─── UPLOAD FICHIER PREUVE ────────────────────────────────────────────────
  static Future<String> _uploadFichier(File fichier) async {
    final request = http.MultipartRequest(
      'POST',
      Uri.parse('$_baseUrl/upload'),
    );
    request.headers.addAll(AuthService.authHeaders);
    request.files.add(await http.MultipartFile.fromPath('file', fichier.path));

    final streamed = await request.send().timeout(const Duration(seconds: 30));
    final response = await http.Response.fromStream(streamed);

    if (response.statusCode == 200) {
      final data = json.decode(response.body) as Map<String, dynamic>;
      return data['url'] as String;
    } else {
      throw Exception('Erreur upload fichier ${response.statusCode}');
    }
  }
}
