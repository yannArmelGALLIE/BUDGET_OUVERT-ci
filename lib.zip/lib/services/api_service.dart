// lib/services/api_service.dart
// Service HTTP principal — communes, transactions, projets, statistiques.
// Les appels protégés utilisent AuthService.authHeaders (Bearer JWT).
// NOTE : les rapports ont été retirés — les communes passent par [ApiService]
// ou [StatiquesData] selon [kUseStaticDemoData].

import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../models/commune_model.dart';
import '../models/transaction_model.dart';
import '../models/projet_model.dart';
import '../models/categorie_model.dart';
import '../models/blockchain_log_model.dart';

class ApiService {
  static const String _baseUrl = 'https://api.budgetouvert.ci';

  // ─── COMMUNES ─────────────────────────────────────────────────────────────

  static Future<List<CommuneModel>> getCommunes({String? recherche}) async {
    try {
      final uri = Uri.parse('$_baseUrl/communes').replace(
        queryParameters: recherche != null ? {'q': recherche} : null,
      );
      final response = await http
          .get(uri, headers: {'Content-Type': 'application/json'})
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((j) => CommuneModel.fromJson(j)).toList();
      } else {
        throw Exception('Erreur ${response.statusCode}');
      }
    } catch (e) {
      if (kDebugMode) print('ApiService.getCommunes: $e');
      rethrow;
    }
  }

  static Future<CommuneModel?> getCommuneDetails(String communeId) async {
    try {
      final response = await http
          .get(
            Uri.parse('$_baseUrl/communes/$communeId'),
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return CommuneModel.fromJson(json.decode(response.body));
      } else if (response.statusCode == 404) {
        return null;
      } else {
        throw Exception('Erreur ${response.statusCode}');
      }
    } catch (e) {
      if (kDebugMode) print('ApiService.getCommuneDetails: $e');
      rethrow;
    }
  }

  // ─── TRANSACTIONS ─────────────────────────────────────────────────────────

  static Future<List<TransactionModel>> getTransactions(
    String communeId, {
    int page = 1,
    int limit = 20,
    String? type,      // 'RECETTE' | 'DEPENSE'
    String? categorie,
  }) async {
    try {
      final params = <String, String>{
        'page': '$page',
        'limit': '$limit',
        if (type != null) 'type': type,
        if (categorie != null) 'categorie': categorie,
      };
      final uri = Uri.parse('$_baseUrl/communes/$communeId/transactions')
          .replace(queryParameters: params);

      final response = await http
          .get(uri, headers: {'Content-Type': 'application/json'})
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((j) => TransactionModel.fromJson(j)).toList();
      } else {
        throw Exception('Erreur ${response.statusCode}');
      }
    } catch (e) {
      if (kDebugMode) print('ApiService.getTransactions: $e');
      rethrow;
    }
  }

  /// Détail d'une transaction par son ID (pour la page détail et le scan QR)
  static Future<TransactionModel?> getTransactionById(
      String transactionId) async {
    try {
      final response = await http
          .get(
            Uri.parse('$_baseUrl/transactions/$transactionId'),
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return TransactionModel.fromJson(json.decode(response.body));
      } else if (response.statusCode == 404) {
        return null;
      } else {
        throw Exception('Erreur ${response.statusCode}');
      }
    } catch (e) {
      if (kDebugMode) print('ApiService.getTransactionById: $e');
      rethrow;
    }
  }

  // ─── PROJETS ──────────────────────────────────────────────────────────────

  static Future<List<ProjetModel>> getProjets(String communeId,
      {int limit = 10}) async {
    try {
      final response = await http
          .get(
            Uri.parse('$_baseUrl/communes/$communeId/projets?limit=$limit'),
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((j) => ProjetModel.fromJson(j)).toList();
      } else {
        throw Exception('Erreur ${response.statusCode}');
      }
    } catch (e) {
      if (kDebugMode) print('ApiService.getProjets: $e');
      rethrow;
    }
  }

  // ─── STATISTIQUES ─────────────────────────────────────────────────────────

  static Future<Map<String, dynamic>> getStatistiques(
      String communeId) async {
    try {
      final response = await http
          .get(
            Uri.parse('$_baseUrl/communes/$communeId/statistiques'),
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body) as Map<String, dynamic>;
      } else {
        throw Exception('Erreur ${response.statusCode}');
      }
    } catch (e) {
      if (kDebugMode) print('ApiService.getStatistiques: $e');
      rethrow;
    }
  }

  // ─── CATÉGORIES ───────────────────────────────────────────────────────────

  static Future<List<CategorieModel>> getCategories() async {
    try {
      final response = await http
          .get(Uri.parse('$_baseUrl/categories'),
              headers: {'Content-Type': 'application/json'})
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((j) => CategorieModel.fromJson(j)).toList();
      } else {
        throw Exception('Erreur ${response.statusCode}');
      }
    } catch (e) {
      if (kDebugMode) print('ApiService.getCategories: $e');
      rethrow;
    }
  }

  // ─── BLOCKCHAIN LOG ───────────────────────────────────────────────────────

  static Future<BlockchainLogModel?> getBlockchainLog(
      String transactionId) async {
    try {
      final response = await http
          .get(
            Uri.parse('$_baseUrl/transactions/$transactionId/blockchain'),
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        return BlockchainLogModel.fromJson(json.decode(response.body));
      } else if (response.statusCode == 404) {
        return null;
      } else {
        throw Exception('Erreur ${response.statusCode}');
      }
    } catch (e) {
      if (kDebugMode) print('ApiService.getBlockchainLog: $e');
      rethrow;
    }
  }
}
