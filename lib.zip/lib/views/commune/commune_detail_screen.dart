// lib/views/commune/commune_detail_screen.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:budgetouvert/models/blockchain_model.dart';
import 'package:budgetouvert/controllers/app_controller.dart';
import 'package:budgetouvert/controllers/commune_controller.dart';
import 'package:budgetouvert/utils/app_constants.dart';
import 'package:budgetouvert/widgets/shared_widgets.dart';
import 'package:budgetouvert/widgets/commune_map_widget.dart';
import 'package:budgetouvert/models/commune_model.dart';

class CommuneDetailScreen extends StatefulWidget {
  const CommuneDetailScreen({super.key});

  @override
  State<CommuneDetailScreen> createState() => _CommuneDetailScreenState();
}

class _CommuneDetailScreenState extends State<CommuneDetailScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final communeKey =
          context.read<AppController>().currentUser?.commune ?? 'adjame';
      context.read<CommuneController>().loadCommune(communeKey);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<CommuneController>(
      builder: (context, ctrl, _) {
        final commune = ctrl.commune;

        return Scaffold(
          backgroundColor: AppColors.background,
          appBar: const BudgetAppBar(),
          body: ctrl.isLoading
              ? const Center(
                  child: CircularProgressIndicator(color: AppColors.primary),
                )
              : ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    // En-tête commune
                    _FocusCommuneCard(commune: commune),

                    // Filtres
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children:
                              ['Tout', 'Adjamé Centre', 'Cocody'].map((f) {
                            final isSelected = ctrl.selectedFilter == f;
                            return GestureDetector(
                              onTap: () => ctrl.setFilter(f),
                              child: Container(
                                margin: const EdgeInsets.only(right: 8),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 8),
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? AppColors.primary
                                      : AppColors.white,
                                  borderRadius: BorderRadius.circular(
                                      AppDimens.radiusFull),
                                  border: Border.all(
                                    color: isSelected
                                        ? AppColors.primary
                                        : AppColors.divider,
                                  ),
                                ),
                                child: Text(
                                  f,
                                  style: AppTextStyles.bodyMedium.copyWith(
                                    color: isSelected
                                        ? AppColors.white
                                        : AppColors.textPrimary,
                                    fontWeight: isSelected
                                        ? FontWeight.w600
                                        : FontWeight.w400,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),

                    // Projets
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                      child: SectionHeader(
                        title: 'Projets en cours',
                        actionLabel: 'Voir tout',
                        onAction: () {},
                      ),
                    ),
                    ...ctrl.filteredProjets
                        .map((p) => _ProjetCard(projet: p))
                        .toList(),

                    // Carte interactive OSM
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                      child: CommuneMapWidget(commune: commune, height: 200),
                    ),

                    _BlockchainSection(ctrl: ctrl),

                    const SizedBox(height: 24),
                  ],
                ),
        );
      },
    );
  }
}

class _BlockchainSection extends StatelessWidget {
  final CommuneController ctrl;
  const _BlockchainSection({required this.ctrl});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _BalanceCard(
            balance: ctrl.balance,
            isLoading: ctrl.isLoadingBlockchain,
            error: ctrl.blockchainError,
          ),
          const SizedBox(height: 16),
          SectionHeader(
            title: 'Mouvements financiers',
            actionLabel: ctrl.transactions.isEmpty ? null : 'Voir tout',
            onAction: () {},
          ),
          const SizedBox(height: 10),
          if (ctrl.isLoadingBlockchain)
            const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: CircularProgressIndicator(color: AppColors.primary),
              ),
            )
          else if (ctrl.blockchainError != null && ctrl.transactions.isEmpty)
            _BlockchainErrorTile(message: ctrl.blockchainError!)
          else if (ctrl.transactions.isEmpty)
            _EmptyTransactionsTile()
          else
            ...ctrl.transactions
                .take(5)
                .map((tx) => _TransactionTile(tx: tx))
                .toList(),
        ],
      ),
    );
  }
}

// ─── FOCUS COMMUNE CARD ────────────────────────────────────────────────────
class _FocusCommuneCard extends StatelessWidget {
  final CommuneModel commune;
  const _FocusCommuneCard({required this.commune});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.primary, AppColors.primaryLight],
        ),
        borderRadius: BorderRadius.circular(AppDimens.radiusXL),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Détails de la Commune',
            style: AppTextStyles.caption.copyWith(
              color: Colors.white70,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Focus\nCommune:\n${commune.name}',
            style: AppTextStyles.displayMedium.copyWith(
              color: AppColors.white,
              height: 1.1,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              _CircularGauge(percent: commune.tauxExecution / 100),
              const SizedBox(width: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Taux d\'exécution\nglobal',
                    style:
                        AppTextStyles.caption.copyWith(color: Colors.white70),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    commune.visionLabel,
                    style: AppTextStyles.bodyMedium.copyWith(
                      color: AppColors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _CircularGauge extends StatelessWidget {
  final double percent;
  const _CircularGauge({required this.percent});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 80,
      height: 80,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CircularProgressIndicator(
            value: percent,
            backgroundColor: AppColors.white.withOpacity(0.2),
            valueColor: const AlwaysStoppedAnimation(AppColors.accent),
            strokeWidth: 7,
          ),
          Text(
            '${(percent * 100).toInt()}%',
            style: AppTextStyles.titleLarge.copyWith(
              color: AppColors.white,
              fontSize: 20,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── PROJECT CARD ──────────────────────────────────────────────────────────
class _ProjetCard extends StatelessWidget {
  final ProjectModel projet;
  const _ProjetCard({required this.projet});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.go('/projet/${projet.id}'),
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(AppDimens.radiusL),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.withOpacity(0.05),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          color: AppColors.primarySurface,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.construction,
                            size: 18, color: AppColors.primary),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              projet.categorie.toUpperCase(),
                              style: AppTextStyles.caption.copyWith(
                                color: AppColors.accent,
                                fontWeight: FontWeight.w700,
                                fontSize: 9,
                              ),
                            ),
                            Text(
                              projet.titre,
                              style: AppTextStyles.titleLarge
                                  .copyWith(fontSize: 14),
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.qr_code,
                          size: 20, color: AppColors.textHint),
                    ],
                  ),
                  const SizedBox(height: 12),
                  StatusChip(
                    label: projet.statut == 'en_cours'
                        ? 'EN PROGRESSION'
                        : projet.statut.toUpperCase(),
                    statut: projet.statut,
                  ),
                  const SizedBox(height: 10),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: projet.progressionGlobale / 100,
                      backgroundColor: AppColors.divider,
                      valueColor: AlwaysStoppedAnimation(
                        projet.statut == 'livré'
                            ? AppColors.success
                            : AppColors.accent,
                      ),
                      minHeight: 8,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Text(
                      '${projet.progressionGlobale.toInt()}%',
                      style: AppTextStyles.caption
                          .copyWith(fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: const BoxDecoration(
                border: Border(top: BorderSide(color: AppColors.divider)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(projet.localisation, style: AppTextStyles.caption),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppColors.primarySurface,
                      borderRadius: BorderRadius.circular(AppDimens.radiusFull),
                    ),
                    child: Text(
                      'Détails',
                      style: AppTextStyles.caption.copyWith(
                        color: AppColors.primary,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BalanceCard extends StatelessWidget {
  final CommuneBalanceModel? balance;
  final bool isLoading;
  final String? error;

  const _BalanceCard({
    required this.balance,
    required this.isLoading,
    required this.error,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.primary, AppColors.primaryLight],
        ),
        borderRadius: BorderRadius.circular(AppDimens.radiusL),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.link, size: 14, color: Colors.white60),
              const SizedBox(width: 6),
              Text(
                'SOLDE BLOCKCHAIN EN TEMPS RÉEL',
                style: AppTextStyles.caption.copyWith(
                  color: Colors.white60,
                  letterSpacing: 1.2,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (isLoading)
            const SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                  color: Colors.white54, strokeWidth: 2),
            )
          else if (error != null && balance == null)
            Text('Indisponible',
                style: AppTextStyles.headlineLarge
                    .copyWith(color: Colors.white54, fontSize: 20))
          else
            Text(
              balance?.balanceFormatted ?? '—',
              style: AppTextStyles.budgetAmount,
            ),
          const SizedBox(height: 6),
          Text(
            'Recettes − Dépenses enregistrées sur Polygon',
            style: AppTextStyles.caption.copyWith(color: Colors.white54),
          ),
        ],
      ),
    );
  }
}

class _TransactionTile extends StatelessWidget {
  final BlockchainTxModel tx;
  const _TransactionTile({required this.tx});

  @override
  Widget build(BuildContext context) {
    final isRevenue = tx.isRevenue;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(AppDimens.radiusM),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.04),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: isRevenue
                  ? AppColors.success.withOpacity(0.1)
                  : AppColors.accent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              isRevenue ? Icons.arrow_downward : Icons.arrow_upward,
              size: 18,
              color: isRevenue ? AppColors.success : AppColors.accent,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  tx.description,
                  style: AppTextStyles.titleLarge.copyWith(fontSize: 13),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    Text(tx.category, style: AppTextStyles.caption),
                    const Text(' • ',
                        style: TextStyle(color: AppColors.textHint)),
                    Text(tx.date, style: AppTextStyles.caption),
                  ],
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    const Icon(Icons.tag, size: 10, color: AppColors.textHint),
                    const SizedBox(width: 3),
                    Text(
                      tx.hashShort,
                      style: AppTextStyles.caption.copyWith(
                        fontSize: 10,
                        color: AppColors.textHint,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${isRevenue ? '+' : '-'} ${tx.amountFormatted}',
                style: AppTextStyles.titleLarge.copyWith(
                  fontSize: 13,
                  color: isRevenue ? AppColors.success : AppColors.accent,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text('FCFA', style: AppTextStyles.caption),
            ],
          ),
        ],
      ),
    );
  }
}

class _EmptyTransactionsTile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(AppDimens.radiusM),
      ),
      child: Center(
        child: Text('Aucune transaction enregistrée',
            style: AppTextStyles.bodyMedium),
      ),
    );
  }
}

class _BlockchainErrorTile extends StatelessWidget {
  final String message;
  const _BlockchainErrorTile({required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.error.withOpacity(0.08),
        borderRadius: BorderRadius.circular(AppDimens.radiusM),
        border: Border.all(color: AppColors.error.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          const Icon(Icons.wifi_off, size: 16, color: AppColors.error),
          const SizedBox(width: 10),
          Text(message,
              style: AppTextStyles.bodyMedium.copyWith(color: AppColors.error)),
        ],
      ),
    );
  }
}
