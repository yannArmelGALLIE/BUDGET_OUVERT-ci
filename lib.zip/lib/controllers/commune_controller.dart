// lib/controllers/commune_controller.dart

import 'package:flutter/material.dart';
import '../models/commune_model.dart';
import '../models/blockchain_model.dart';
import '../services/api_service.dart';

// ═══════════════════════════════════════════════════════════════════
//  COMMUNE CONTROLLER — données via ApiService
// ═══════════════════════════════════════════════════════════════════

class CommuneController extends ChangeNotifier {
  CommuneModel _commune = CommuneModel.sample();
  String _selectedFilter = 'Tout';
  bool _isLoading = false;

  // ── Données blockchain live ───────────────────────────────────
  CommuneBalanceModel? _balance;
  List<BlockchainTxModel> _transactions = [];
  bool _isLoadingBlockchain = false;
  String? _blockchainError;

  CommuneModel get commune => _commune;
  String get selectedFilter => _selectedFilter;
  bool get isLoading => _isLoading;

  CommuneBalanceModel? get balance => _balance;
  List<BlockchainTxModel> get transactions => _transactions;
  bool get isLoadingBlockchain => _isLoadingBlockchain;
  String? get blockchainError => _blockchainError;

  List<BlockchainTxModel> get recettes =>
      _transactions.where((t) => t.isRevenue).toList();

  List<BlockchainTxModel> get depenses =>
      _transactions.where((t) => !t.isRevenue).toList();

  int get totalRecettes => recettes.fold(0, (sum, t) => sum + t.amount);

  List<ProjectModel> get filteredProjets {
    if (_selectedFilter == 'Tout') return _commune.projets;
    return _commune.projets
        .where((p) =>
            p.commune == _selectedFilter || p.categorie == _selectedFilter)
        .toList();
  }

  void setFilter(String filter) {
    _selectedFilter = filter;
    notifyListeners();
  }

  Future<void> loadCommune(String id) async {
    _isLoading = true;
    notifyListeners();

    try {
      _commune = await ApiService.instance.getCommune(id);
    } catch (_) {
      // garde les données locales en cas d'erreur
    } finally {
      _isLoading = false;
      notifyListeners();
    }

    // charge blockchain en parallèle, non bloquant
    _loadBlockchainData(id);
  }

  Future<void> _loadBlockchainData(String communeKey) async {
    _isLoadingBlockchain = true;
    _blockchainError = null;
    notifyListeners();

    try {
      final results = await Future.wait([
        ApiService.instance.getCommuneBalance(communeKey),
        ApiService.instance.getCommuneTransactions(communeKey),
      ]);
      _balance = results[0] as CommuneBalanceModel;
      _transactions = results[1] as List<BlockchainTxModel>;
    } catch (e) {
      _blockchainError = 'Données blockchain indisponibles';
    } finally {
      _isLoadingBlockchain = false;
      notifyListeners();
    }
  }

  Future<void> refreshBlockchain(String communeKey) =>
      _loadBlockchainData(communeKey);
}
