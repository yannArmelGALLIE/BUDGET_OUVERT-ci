// lib/data/statiques_data.dart
// Données de démonstration — conservées pour tests et mode démo.
// Activées uniquement si `kUseStaticDemoData` est `true` dans
// lib/utils/data_source_config.dart (via [CommuneDataService]).
// Toutes les liaisons (commune ↔ transaction ↔ catégorie ↔ blockchain_log,
// projet ↔ commune, signalement ↔ transaction ↔ citoyen) sont cohérentes.
//
// Usage :
//   import '../data/statiques_data.dart';
//   final communes = StatiquesData.communes;
//   final txs = StatiquesData.transactionsDe('COM-001');

import '../models/categorie_model.dart';
import '../models/commune_model.dart';
import '../models/transaction_model.dart';
import '../models/projet_model.dart';
import '../models/blockchain_log_model.dart';
import '../models/signalement_model.dart';
import '../models/citoyen_model.dart';

class StatiquesData {
  StatiquesData._();

  // ═══════════════════════════════════════════════════════════════════════════
  // CATÉGORIES  (id_categorie utilisé comme clé dans les transactions)
  // ═══════════════════════════════════════════════════════════════════════════

  static final List<CategorieModel> categories = [
    // ── Recettes ──────────────────────────────────────────────────────────
    CategorieModel.fromJson({
      'id_categorie': 1,
      'libelle': 'Impôts locaux',
      'type_budget': 'RECETTE',
      'icone': 'account_balance',
      'couleur_hex': '#2D9B6B',
      'description': 'Taxes foncières, taxes d\'habitation et patentes',
    }),
    CategorieModel.fromJson({
      'id_categorie': 2,
      'libelle': 'Transferts de l\'État',
      'type_budget': 'RECETTE',
      'icone': 'swap_horiz',
      'couleur_hex': '#3B82F6',
      'description': 'Dotations globales et subventions de fonctionnement',
    }),
    CategorieModel.fromJson({
      'id_categorie': 3,
      'libelle': 'Recettes domaniales',
      'type_budget': 'RECETTE',
      'icone': 'landscape',
      'couleur_hex': '#8B5CF6',
      'description': 'Location de marchés, cimetières, espaces publics',
    }),
    CategorieModel.fromJson({
      'id_categorie': 4,
      'libelle': 'Droits et taxes divers',
      'type_budget': 'RECETTE',
      'icone': 'receipt_long',
      'couleur_hex': '#10B981',
      'description': 'Droits de stationnement, publicité, licences',
    }),
    // ── Dépenses ──────────────────────────────────────────────────────────
    CategorieModel.fromJson({
      'id_categorie': 5,
      'libelle': 'Personnel',
      'type_budget': 'DEPENSE',
      'icone': 'group',
      'couleur_hex': '#E07B3A',
      'description': 'Salaires, cotisations sociales, indemnités',
    }),
    CategorieModel.fromJson({
      'id_categorie': 6,
      'libelle': 'Travaux & Infrastructure',
      'type_budget': 'DEPENSE',
      'icone': 'construction',
      'couleur_hex': '#D64545',
      'description': 'Routes, bâtiments communaux, réseaux',
    }),
    CategorieModel.fromJson({
      'id_categorie': 7,
      'libelle': 'Santé & Hygiène',
      'type_budget': 'DEPENSE',
      'icone': 'local_hospital',
      'couleur_hex': '#EC4899',
      'description': 'Centres de santé, collecte des ordures, assainissement',
    }),
    CategorieModel.fromJson({
      'id_categorie': 8,
      'libelle': 'Éducation',
      'type_budget': 'DEPENSE',
      'icone': 'school',
      'couleur_hex': '#F59E0B',
      'description': 'Écoles primaires, cantines scolaires, mobilier',
    }),
    CategorieModel.fromJson({
      'id_categorie': 9,
      'libelle': 'Fonctionnement',
      'type_budget': 'DEPENSE',
      'icone': 'settings',
      'couleur_hex': '#6B7280',
      'description': 'Fournitures, énergie, téléphonie, informatique',
    }),
    CategorieModel.fromJson({
      'id_categorie': 10,
      'libelle': 'Eau & Électricité',
      'type_budget': 'DEPENSE',
      'icone': 'bolt',
      'couleur_hex': '#06B6D4',
      'description': 'Factures SODECI, CIE, éclairage public',
    }),
  ];

  // ═══════════════════════════════════════════════════════════════════════════
  // COMMUNES
  // ═══════════════════════════════════════════════════════════════════════════

  static final List<CommuneModel> communes = [
    CommuneModel.fromJson({
      'id_commune': 'COM-001',
      'nom_commune': 'Abobo',
      'departement': 'Abidjan',
      'region': 'Lagunes',
      'population': 1075543,
      'email_contact': 'mairie@abobo.ci',
      'telephone': '+225 27 20 37 10 00',
      'logo_url': null,
      'statut_actif': true,
      'budget': 4800000000.0,
      'budget_utilise': 3120000000.0,
      'date_inscription': '2023-01-15T08:00:00.000Z',
    }),
    CommuneModel.fromJson({
      'id_commune': 'COM-002',
      'nom_commune': 'Yopougon',
      'departement': 'Abidjan',
      'region': 'Lagunes',
      'population': 1071543,
      'email_contact': 'contact@yopougon.ci',
      'telephone': '+225 27 22 41 52 00',
      'logo_url': null,
      'statut_actif': true,
      'budget': 5200000000.0,
      'budget_utilise': 3640000000.0,
      'date_inscription': '2023-02-01T08:00:00.000Z',
    }),
    CommuneModel.fromJson({
      'id_commune': 'COM-003',
      'nom_commune': 'Koumassi',
      'departement': 'Abidjan',
      'region': 'Lagunes',
      'population': 566560,
      'email_contact': 'mairie.koumassi@ci.ci',
      'telephone': '+225 27 21 24 38 00',
      'logo_url': null,
      'statut_actif': true,
      'budget': 2100000000.0,
      'budget_utilise': 1134000000.0,
      'date_inscription': '2023-03-10T08:00:00.000Z',
    }),
    CommuneModel.fromJson({
      'id_commune': 'COM-004',
      'nom_commune': 'Marcory',
      'departement': 'Abidjan',
      'region': 'Lagunes',
      'population': 249983,
      'email_contact': 'info@marcory.ci',
      'telephone': '+225 27 21 26 11 00',
      'logo_url': null,
      'statut_actif': true,
      'budget': 1650000000.0,
      'budget_utilise': 1023000000.0,
      'date_inscription': '2023-04-05T08:00:00.000Z',
    }),
    CommuneModel.fromJson({
      'id_commune': 'COM-005',
      'nom_commune': 'Plateau',
      'departement': 'Abidjan',
      'region': 'Lagunes',
      'population': 24000,
      'email_contact': 'mairie.plateau@abidjan.ci',
      'telephone': '+225 27 20 22 54 00',
      'logo_url': null,
      'statut_actif': true,
      'budget': 3400000000.0,
      'budget_utilise': 2550000000.0,
      'date_inscription': '2023-01-20T08:00:00.000Z',
    }),
    CommuneModel.fromJson({
      'id_commune': 'COM-006',
      'nom_commune': 'Bouaké',
      'departement': 'Bouaké',
      'region': 'Vallée du Bandama',
      'population': 536189,
      'email_contact': 'mairie@bouake.ci',
      'telephone': '+225 27 31 63 50 00',
      'logo_url': null,
      'statut_actif': true,
      'budget': 2800000000.0,
      'budget_utilise': 1680000000.0,
      'date_inscription': '2023-05-15T08:00:00.000Z',
    }),
    CommuneModel.fromJson({
      'id_commune': 'COM-007',
      'nom_commune': 'San Pedro',
      'departement': 'San Pedro',
      'region': 'Bas-Sassandra',
      'population': 221532,
      'email_contact': 'mairie.sanpedro@ci.ci',
      'telephone': '+225 27 34 71 22 00',
      'logo_url': null,
      'statut_actif': true,
      'budget': 1500000000.0,
      'budget_utilise': 900000000.0,
      'date_inscription': '2023-06-01T08:00:00.000Z',
    }),
  ];

  // ═══════════════════════════════════════════════════════════════════════════
  // TRANSACTIONS  (liées aux communes et catégories ci-dessus)
  // Champs respectant exactement TransactionModel.fromJson
  // ═══════════════════════════════════════════════════════════════════════════

  static final List<Map<String, dynamic>> _txRaw = [
    // ── COM-001 · Abobo ───────────────────────────────────────────────────
    {
      'id_transaction': 'TX-001',
      'id_commune': 'COM-001',
      'id_categorie': 2,
      'categorie_libelle': 'Transferts de l\'État',
      'categorie_icone': 'swap_horiz',
      'categorie_couleur': '#3B82F6',
      'libelle': 'Dotation globale Q1 2025',
      'description':
          'Virement de la Direction Générale de la Décentralisation au titre du premier trimestre 2025.',
      'montant_fcfa': 820000000.0,
      'type': 'RECETTE',
      'date_transaction': '2025-01-15T09:30:00.000Z',
      'statut': 'PUBLIE',
      'piece_justificative_url':
          'https://cdn.budgetouvert.ci/docs/tx-001-ordre.pdf',
      'hash_blockchain':
          'a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2',
      'audio_url': null,
      'audio_langue': null,
      'reference': 'DGD/Q1/2025/0042',
      'date_validation': '2025-01-16T08:00:00.000Z',
      'date_publication': '2025-01-17T08:00:00.000Z',
    },
    {
      'id_transaction': 'TX-002',
      'id_commune': 'COM-001',
      'id_categorie': 1,
      'categorie_libelle': 'Impôts locaux',
      'categorie_icone': 'account_balance',
      'categorie_couleur': '#2D9B6B',
      'libelle': 'Recouvrement taxe foncière — Jan 2025',
      'description':
          'Recettes de la taxe foncière sur les propriétés bâties du mois de janvier 2025.',
      'montant_fcfa': 145000000.0,
      'type': 'RECETTE',
      'date_transaction': '2025-01-31T17:00:00.000Z',
      'statut': 'PUBLIE',
      'piece_justificative_url': null,
      'hash_blockchain':
          'b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3',
      'audio_url': 'https://cdn.budgetouvert.ci/audio/tx-002-fr.mp3',
      'audio_langue': 'fr',
      'reference': 'TFONC/JAN/2025',
      'date_validation': '2025-02-02T08:00:00.000Z',
      'date_publication': '2025-02-03T08:00:00.000Z',
    },
    {
      'id_transaction': 'TX-003',
      'id_commune': 'COM-001',
      'id_categorie': 5,
      'categorie_libelle': 'Personnel',
      'categorie_icone': 'group',
      'categorie_couleur': '#E07B3A',
      'libelle': 'Salaires agents municipaux — Jan 2025',
      'description':
          'Paiement des rémunérations de 1 248 agents de la mairie d\'Abobo pour le mois de janvier 2025.',
      'montant_fcfa': 312000000.0,
      'type': 'DEPENSE',
      'date_transaction': '2025-01-28T10:00:00.000Z',
      'statut': 'PUBLIE',
      'piece_justificative_url':
          'https://cdn.budgetouvert.ci/docs/tx-003-paie.pdf',
      'hash_blockchain':
          'c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4',
      'audio_url': 'https://cdn.budgetouvert.ci/audio/tx-003-dioula.mp3',
      'audio_langue': 'dioula',
      'reference': 'RH/JAN/2025/PAIE',
      'date_validation': '2025-01-29T08:00:00.000Z',
      'date_publication': '2025-01-30T08:00:00.000Z',
    },
    {
      'id_transaction': 'TX-004',
      'id_commune': 'COM-001',
      'id_categorie': 6,
      'categorie_libelle': 'Travaux & Infrastructure',
      'categorie_icone': 'construction',
      'categorie_couleur': '#D64545',
      'libelle': 'Réhabilitation route Abobo-Baoule',
      'description':
          'Paiement de la 1ère tranche pour la réhabilitation de 3,2 km de voie bitumée reliant Abobo à Baoule — lot n°1.',
      'montant_fcfa': 480000000.0,
      'type': 'DEPENSE',
      'date_transaction': '2025-02-10T11:00:00.000Z',
      'statut': 'PUBLIE',
      'piece_justificative_url':
          'https://cdn.budgetouvert.ci/docs/tx-004-marche.pdf',
      'hash_blockchain':
          'd4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5',
      'audio_url': null,
      'audio_langue': null,
      'reference': 'TRV/2025/LOT01-T1',
      'date_validation': '2025-02-12T08:00:00.000Z',
      'date_publication': '2025-02-14T08:00:00.000Z',
    },
    {
      'id_transaction': 'TX-005',
      'id_commune': 'COM-001',
      'id_categorie': 7,
      'categorie_libelle': 'Santé & Hygiène',
      'categorie_icone': 'local_hospital',
      'categorie_couleur': '#EC4899',
      'libelle': 'Collecte ordures ménagères — Fév 2025',
      'description':
          'Prestation mensuelle de collecte et traitement des ordures ménagères par SITAF.',
      'montant_fcfa': 38500000.0,
      'type': 'DEPENSE',
      'date_transaction': '2025-02-28T14:00:00.000Z',
      'statut': 'PUBLIE',
      'piece_justificative_url':
          'https://cdn.budgetouvert.ci/docs/tx-005-sitaf.pdf',
      'hash_blockchain':
          'e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6',
      'audio_url': null,
      'audio_langue': null,
      'reference': 'SITAF/FEV/2025',
      'date_validation': '2025-03-01T08:00:00.000Z',
      'date_publication': '2025-03-02T08:00:00.000Z',
    },
    {
      'id_transaction': 'TX-006',
      'id_commune': 'COM-001',
      'id_categorie': 3,
      'categorie_libelle': 'Recettes domaniales',
      'categorie_icone': 'landscape',
      'categorie_couleur': '#8B5CF6',
      'libelle': 'Loyers marchés communaux — Fév 2025',
      'description':
          'Perception des droits de place et loyers des 4 marchés communaux d\'Abobo pour février.',
      'montant_fcfa': 22400000.0,
      'type': 'RECETTE',
      'date_transaction': '2025-02-28T16:00:00.000Z',
      'statut': 'PUBLIE',
      'piece_justificative_url': null,
      'hash_blockchain':
          'f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1',
      'audio_url': null,
      'audio_langue': null,
      'reference': 'DOM/MARCH/FEV/2025',
      'date_validation': '2025-03-01T08:00:00.000Z',
      'date_publication': '2025-03-02T08:00:00.000Z',
    },
    // ── COM-002 · Yopougon ────────────────────────────────────────────────
    {
      'id_transaction': 'TX-007',
      'id_commune': 'COM-002',
      'id_categorie': 2,
      'categorie_libelle': 'Transferts de l\'État',
      'categorie_icone': 'swap_horiz',
      'categorie_couleur': '#3B82F6',
      'libelle': 'Dotation globale Q1 2025',
      'description':
          'Subvention de fonctionnement Q1 2025 — Direction Générale de la Décentralisation.',
      'montant_fcfa': 920000000.0,
      'type': 'RECETTE',
      'date_transaction': '2025-01-15T09:00:00.000Z',
      'statut': 'PUBLIE',
      'piece_justificative_url':
          'https://cdn.budgetouvert.ci/docs/tx-007-dgd.pdf',
      'hash_blockchain':
          '1a2b3c4d5e6f1a2b3c4d5e6f1a2b3c4d5e6f1a2b3c4d5e6f1a2b3c4d5e6f1a2b',
      'audio_url': null,
      'audio_langue': null,
      'reference': 'DGD/Q1/2025/0043',
      'date_validation': '2025-01-16T08:00:00.000Z',
      'date_publication': '2025-01-17T08:00:00.000Z',
    },
    {
      'id_transaction': 'TX-008',
      'id_commune': 'COM-002',
      'id_categorie': 8,
      'categorie_libelle': 'Éducation',
      'categorie_icone': 'school',
      'categorie_couleur': '#F59E0B',
      'libelle': 'Construction groupe scolaire Niangon Nord',
      'description':
          'Mise en place des fondations du nouveau groupe scolaire de 12 salles à Niangon Nord — tranche 1.',
      'montant_fcfa': 265000000.0,
      'type': 'DEPENSE',
      'date_transaction': '2025-02-05T10:00:00.000Z',
      'statut': 'PUBLIE',
      'piece_justificative_url':
          'https://cdn.budgetouvert.ci/docs/tx-008-ecole.pdf',
      'hash_blockchain':
          '2b3c4d5e6f1a2b3c4d5e6f1a2b3c4d5e6f1a2b3c4d5e6f1a2b3c4d5e6f1a2b3c',
      'audio_url': 'https://cdn.budgetouvert.ci/audio/tx-008-fr.mp3',
      'audio_langue': 'fr',
      'reference': 'EDU/YOP/2025/ECO01-T1',
      'date_validation': '2025-02-07T08:00:00.000Z',
      'date_publication': '2025-02-08T08:00:00.000Z',
    },
    {
      'id_transaction': 'TX-009',
      'id_commune': 'COM-002',
      'id_categorie': 10,
      'categorie_libelle': 'Eau & Électricité',
      'categorie_icone': 'bolt',
      'categorie_couleur': '#06B6D4',
      'libelle': 'Facture CIE éclairage public — Jan 2025',
      'description':
          'Règlement de la facture d\'éclairage public auprès de la CIE pour le mois de janvier 2025.',
      'montant_fcfa': 18700000.0,
      'type': 'DEPENSE',
      'date_transaction': '2025-02-10T14:00:00.000Z',
      'statut': 'PUBLIE',
      'piece_justificative_url':
          'https://cdn.budgetouvert.ci/docs/tx-009-cie.pdf',
      'hash_blockchain':
          '3c4d5e6f1a2b3c4d5e6f1a2b3c4d5e6f1a2b3c4d5e6f1a2b3c4d5e6f1a2b3c4d',
      'audio_url': null,
      'audio_langue': null,
      'reference': 'CIE/YOP/JAN2025',
      'date_validation': '2025-02-11T08:00:00.000Z',
      'date_publication': '2025-02-12T08:00:00.000Z',
    },
    // ── COM-003 · Koumassi ────────────────────────────────────────────────
    {
      'id_transaction': 'TX-010',
      'id_commune': 'COM-003',
      'id_categorie': 1,
      'categorie_libelle': 'Impôts locaux',
      'categorie_icone': 'account_balance',
      'categorie_couleur': '#2D9B6B',
      'libelle': 'Patentes et licences commerciales — T4 2024',
      'description':
          'Recouvrement des patentes et licences commerciales du quatrième trimestre 2024.',
      'montant_fcfa': 67300000.0,
      'type': 'RECETTE',
      'date_transaction': '2025-01-10T09:00:00.000Z',
      'statut': 'PUBLIE',
      'piece_justificative_url': null,
      'hash_blockchain':
          '4d5e6f1a2b3c4d5e6f1a2b3c4d5e6f1a2b3c4d5e6f1a2b3c4d5e6f1a2b3c4d5e',
      'audio_url': null,
      'audio_langue': null,
      'reference': 'PAT/T4/2024',
      'date_validation': '2025-01-11T08:00:00.000Z',
      'date_publication': '2025-01-12T08:00:00.000Z',
    },
    {
      'id_transaction': 'TX-011',
      'id_commune': 'COM-003',
      'id_categorie': 9,
      'categorie_libelle': 'Fonctionnement',
      'categorie_icone': 'settings',
      'categorie_couleur': '#6B7280',
      'libelle': 'Fournitures de bureau et informatique — Jan 2025',
      'description':
          'Achat de consommables, papeterie et maintenance informatique pour la mairie de Koumassi.',
      'montant_fcfa': 4200000.0,
      'type': 'DEPENSE',
      'date_transaction': '2025-01-22T11:00:00.000Z',
      'statut': 'PUBLIE',
      'piece_justificative_url':
          'https://cdn.budgetouvert.ci/docs/tx-011-fournit.pdf',
      'hash_blockchain':
          '5e6f1a2b3c4d5e6f1a2b3c4d5e6f1a2b3c4d5e6f1a2b3c4d5e6f1a2b3c4d5e6f',
      'audio_url': null,
      'audio_langue': null,
      'reference': 'FONCT/JAN/2025/INF',
      'date_validation': '2025-01-23T08:00:00.000Z',
      'date_publication': '2025-01-24T08:00:00.000Z',
    },
  ];

  static List<TransactionModel> get transactions =>
      _txRaw.map((j) => TransactionModel.fromJson(j)).toList();

  /// Retourne les transactions d'une commune donnée
  static List<TransactionModel> transactionsDe(String communeId) =>
      transactions.where((t) => t.communeId == communeId).toList();

  /// Retourne une transaction par son ID
  static TransactionModel? transactionParId(String id) {
    try {
      return transactions.firstWhere((t) => t.id == id);
    } catch (_) {
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // PROJETS  (liés aux communes)
  // ═══════════════════════════════════════════════════════════════════════════

  static final List<ProjetModel> projets = [
    ProjetModel.fromJson({
      'id': 'PRJ-001',
      'commune_id': 'COM-001',
      'titre': 'Réhabilitation des voiries d\'Abobo',
      'description':
          'Réhabilitation de 8,5 km de voies bitumées dans les quartiers Derrière Rails et PK18. '
              'Inclut pose de bordures, cunettes et signalisation horizontale.',
      'budget_total': 1200000000.0,
      'budget_utilise': 480000000.0,
      'statut': 'en_cours',
      'date_debut': '2025-01-10T00:00:00.000Z',
      'date_fin': '2025-09-30T00:00:00.000Z',
      'responsable': 'Direction Technique Municipale',
      'images': [
        'https://cdn.budgetouvert.ci/projets/prj-001-chantier.jpg',
      ],
    }),
    ProjetModel.fromJson({
      'id': 'PRJ-002',
      'commune_id': 'COM-001',
      'titre': 'Construction de 3 blocs de latrines scolaires',
      'description':
          'Réalisation de blocs sanitaires séparés (filles / garçons) dans 3 écoles primaires '
              'de la commune : EPP Abobo Nord, EPP Sogefiha et EPP Anador.',
      'budget_total': 78000000.0,
      'budget_utilise': 78000000.0,
      'statut': 'termine',
      'date_debut': '2024-10-01T00:00:00.000Z',
      'date_fin': '2025-01-15T00:00:00.000Z',
      'responsable': 'Service des Bâtiments Scolaires',
      'images': [],
    }),
    ProjetModel.fromJson({
      'id': 'PRJ-003',
      'commune_id': 'COM-002',
      'titre': 'Groupe scolaire Niangon Nord — 12 salles',
      'description':
          'Construction d\'un nouveau groupe scolaire de 12 salles de classe, bureau de direction, '
              'salle des maîtres et cuisine de cantine à Niangon Nord.',
      'budget_total': 530000000.0,
      'budget_utilise': 265000000.0,
      'statut': 'en_cours',
      'date_debut': '2025-02-01T00:00:00.000Z',
      'date_fin': '2026-01-31T00:00:00.000Z',
      'responsable': 'Direction Éducation & Jeunesse',
      'images': [
        'https://cdn.budgetouvert.ci/projets/prj-003-plan.jpg',
      ],
    }),
    ProjetModel.fromJson({
      'id': 'PRJ-004',
      'commune_id': 'COM-002',
      'titre': 'Rénovation centre de santé Toit Rouge',
      'description':
          'Remise à neuf complète du centre de santé urbain de Toit Rouge : toiture, '
              'plomberie, électricité et équipements médicaux de base.',
      'budget_total': 145000000.0,
      'budget_utilise': 0.0,
      'statut': 'en_attente',
      'date_debut': '2025-06-01T00:00:00.000Z',
      'date_fin': null,
      'responsable': 'Direction Hygiène & Santé',
      'images': [],
    }),
    ProjetModel.fromJson({
      'id': 'PRJ-005',
      'commune_id': 'COM-003',
      'titre': 'Marché moderne de Koumassi',
      'description':
          'Extension et modernisation du marché central de Koumassi : 240 nouvelles boutiques, '
              'hangar couvert, chambre froide et parking.',
      'budget_total': 620000000.0,
      'budget_utilise': 186000000.0,
      'statut': 'en_cours',
      'date_debut': '2025-03-01T00:00:00.000Z',
      'date_fin': '2026-06-30T00:00:00.000Z',
      'responsable': 'Direction Commerce & Marchés',
      'images': [],
    }),
  ];

  /// Projets d'une commune donnée
  static List<ProjetModel> projetsDe(String communeId) =>
      projets.where((p) => p.communeId == communeId).toList();

  // ═══════════════════════════════════════════════════════════════════════════
  // STATISTIQUES  (calculées à partir des transactions, prêtes à l'emploi)
  // Structure identique à ce que retournera GET /communes/:id/statistiques
  // ═══════════════════════════════════════════════════════════════════════════

  static Map<String, dynamic> statistiquesDe(String communeId) {
    final txs = transactionsDe(communeId);
    final recettes = txs.where((t) => t.isRevenue ?? false).toList();
    final depenses = txs.where((t) => !(t.isRevenue ?? false)).toList();

    final totalRecettes = recettes.fold<double>(0, (s, t) => s + t.amount);
    final totalDepenses = depenses.fold<double>(0, (s, t) => s + t.amount);

    // Répartition par catégorie pour les graphiques
    final Map<String, double> parCategorie = {};
    for (final t in txs) {
      parCategorie[t.category] = (parCategorie[t.category] ?? 0) + t.amount;
    }

    // Évolution mensuelle simplifiée (6 derniers mois fictifs cohérents)
    final evolutionMensuelle = _evolutionMensuelle(communeId);

    return {
      'commune_id': communeId,
      'total_recettes': totalRecettes,
      'total_depenses': totalDepenses,
      'solde': totalRecettes - totalDepenses,
      'nb_transactions': txs.length,
      'nb_recettes': recettes.length,
      'nb_depenses': depenses.length,
      'repartition_categories': parCategorie,
      'evolution_mensuelle': evolutionMensuelle,
      'periode': 'jan-mars 2025',
    };
  }

  static List<Map<String, dynamic>> _evolutionMensuelle(String communeId) {
    // Données cohérentes avec les budgets de chaque commune
    final Map<String, List<Map<String, dynamic>>> data = {
      'COM-001': [
        {'mois': 'Nov', 'recettes': 520000000, 'depenses': 390000000},
        {'mois': 'Déc', 'recettes': 480000000, 'depenses': 420000000},
        {'mois': 'Jan', 'recettes': 987000000, 'depenses': 350500000},
        {'mois': 'Fév', 'recettes': 22400000, 'depenses': 518500000},
        {'mois': 'Mar', 'recettes': 110000000, 'depenses': 295000000},
        {'mois': 'Avr', 'recettes': 95000000, 'depenses': 312000000},
      ],
      'COM-002': [
        {'mois': 'Nov', 'recettes': 630000000, 'depenses': 470000000},
        {'mois': 'Déc', 'recettes': 590000000, 'depenses': 505000000},
        {'mois': 'Jan', 'recettes': 920000000, 'depenses': 420000000},
        {'mois': 'Fév', 'recettes': 80000000, 'depenses': 283700000},
        {'mois': 'Mar', 'recettes': 130000000, 'depenses': 380000000},
        {'mois': 'Avr', 'recettes': 115000000, 'depenses': 360000000},
      ],
      'COM-003': [
        {'mois': 'Nov', 'recettes': 210000000, 'depenses': 155000000},
        {'mois': 'Déc', 'recettes': 195000000, 'depenses': 170000000},
        {'mois': 'Jan', 'recettes': 67300000, 'depenses': 4200000},
        {'mois': 'Fév', 'recettes': 50000000, 'depenses': 95000000},
        {'mois': 'Mar', 'recettes': 75000000, 'depenses': 110000000},
        {'mois': 'Avr', 'recettes': 60000000, 'depenses': 88000000},
      ],
    };
    return data[communeId] ??
        [
          {'mois': 'Jan', 'recettes': 100000000, 'depenses': 80000000},
          {'mois': 'Fév', 'recettes': 120000000, 'depenses': 90000000},
          {'mois': 'Mar', 'recettes': 110000000, 'depenses': 95000000},
        ];
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // BLOCKCHAIN LOGS  (1 log par transaction publiée)
  // ═══════════════════════════════════════════════════════════════════════════

  static final List<BlockchainLogModel> blockchainLogs = [
    BlockchainLogModel.fromJson({
      'id_log': 'BL-001',
      'id_transaction': 'TX-001',
      'hash_bloc':
          'a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2',
      'hash_precedent':
          '0000000000000000000000000000000000000000000000000000000000000000',
      'numero_bloc': 1001,
      'timestamp_chain': '2025-01-17T09:00:00.000Z',
      'adresse_noeud': 'node-abidjan-01.budgetouvert.ci',
      'signature_numerique': 'SIG-a1b2c3d4e5f6',
    }),
    BlockchainLogModel.fromJson({
      'id_log': 'BL-002',
      'id_transaction': 'TX-002',
      'hash_bloc':
          'b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3',
      'hash_precedent':
          'a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2',
      'numero_bloc': 1002,
      'timestamp_chain': '2025-02-03T09:30:00.000Z',
      'adresse_noeud': 'node-abidjan-01.budgetouvert.ci',
      'signature_numerique': 'SIG-b2c3d4e5f6a1',
    }),
    BlockchainLogModel.fromJson({
      'id_log': 'BL-003',
      'id_transaction': 'TX-003',
      'hash_bloc':
          'c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4',
      'hash_precedent':
          'b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3',
      'numero_bloc': 1003,
      'timestamp_chain': '2025-01-30T10:00:00.000Z',
      'adresse_noeud': 'node-bouake-01.budgetouvert.ci',
      'signature_numerique': 'SIG-c3d4e5f6a1b2',
    }),
    BlockchainLogModel.fromJson({
      'id_log': 'BL-004',
      'id_transaction': 'TX-004',
      'hash_bloc':
          'd4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5',
      'hash_precedent':
          'c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4',
      'numero_bloc': 1004,
      'timestamp_chain': '2025-02-14T11:00:00.000Z',
      'adresse_noeud': 'node-abidjan-02.budgetouvert.ci',
      'signature_numerique': 'SIG-d4e5f6a1b2c3',
    }),
    BlockchainLogModel.fromJson({
      'id_log': 'BL-005',
      'id_transaction': 'TX-005',
      'hash_bloc':
          'e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6',
      'hash_precedent':
          'd4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5',
      'numero_bloc': 1005,
      'timestamp_chain': '2025-03-02T14:00:00.000Z',
      'adresse_noeud': 'node-abidjan-01.budgetouvert.ci',
      'signature_numerique': 'SIG-e5f6a1b2c3d4',
    }),
  ];

  /// Retourne le log blockchain d'une transaction
  static BlockchainLogModel? blockchainLogDe(String transactionId) {
    try {
      return blockchainLogs.firstWhere((l) => l.transactionId == transactionId);
    } catch (_) {
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // CITOYEN DE DÉMO  (pour tester les flux connectés)
  // ═══════════════════════════════════════════════════════════════════════════

  static final CitoyenModel citoyenDemo = CitoyenModel.fromJson({
    'id_citoyen': 'CTY-001',
    'nom': 'Kouamé',
    'prenom': 'Adjoua Marie',
    'email': 'adjoua.kouame@demo.ci',
    'telephone': '+225 07 01 02 03 04',
    'id_commune': 'COM-001',
    'commune_nom': 'Abobo',
    'token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.DEMO_TOKEN',
    'notification_actif': true,
    'langue_preferee': 'fr',
    'role': 'CITOYEN',
    'statut_compte': 'ACTIF',
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // SIGNALEMENTS  (liés aux transactions et au citoyen de démo)
  // ═══════════════════════════════════════════════════════════════════════════

  static final List<SignalementModel> signalements = [
    SignalementModel.fromJson({
      'id': 'SIG-001',
      'transaction_id': 'TX-004',
      'citoyen_id': 'CTY-001',
      'citoyen_nom': 'Adjoua Marie Kouamé',
      'type': 'erreur',
      'commentaire':
          'Le montant de 480 000 000 FCFA semble supérieur au devis initial de 350 000 000 FCFA '
              'approuvé en conseil municipal. Veuillez vérifier.',
      'preuves': [
        'https://cdn.budgetouvert.ci/preuves/sig-001-photo.jpg',
      ],
      'statut': 'enCours',
      'date_signalement': '2025-02-15T08:30:00.000Z',
      'date_mise_a_jour': '2025-02-18T10:00:00.000Z',
    }),
    SignalementModel.fromJson({
      'id': 'SIG-002',
      'transaction_id': 'TX-003',
      'citoyen_id': 'CTY-001',
      'citoyen_nom': 'Adjoua Marie Kouamé',
      'type': 'doublon',
      'commentaire':
          'Cette transaction de paiement de salaires semble être un doublon de la référence RH/DEC/2024/PAIE '
              'déjà publiée en décembre 2024.',
      'preuves': [],
      'statut': 'resolu',
      'date_signalement': '2025-02-01T11:00:00.000Z',
      'date_mise_a_jour': '2025-02-05T14:00:00.000Z',
    }),
  ];

  /// Signalements liés à une transaction
  static List<SignalementModel> signalementsDe(String transactionId) =>
      signalements.where((s) => s.transactionId == transactionId).toList();

  /// Signalements du citoyen connecté
  static List<SignalementModel> mesSignalements(String citoyenId) =>
      signalements.where((s) => s.citoyenId == citoyenId).toList();
}
