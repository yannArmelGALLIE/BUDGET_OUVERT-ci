// lib/models/projet_model.dart
class ProjetModel {
  final String id;
  final String communeId;
  final String titre;
  final String description;
  final double budgetTotal;
  final double budgetUtilise;
  final String statut; // 'en_cours', 'termine', 'en_attente', 'annule'
  final DateTime dateDebut;
  final DateTime? dateFin;
  final String? responsable;
  final List<String> images;

  const ProjetModel({
    required this.id,
    required this.communeId,
    required this.titre,
    required this.description,
    required this.budgetTotal,
    required this.budgetUtilise,
    required this.statut,
    required this.dateDebut,
    this.dateFin,
    this.responsable,
    this.images = const [],
  });

  factory ProjetModel.fromJson(Map<String, dynamic> json) {
    return ProjetModel(
      id: json['id'] as String,
      communeId: json['commune_id'] as String,
      titre: json['titre'] as String,
      description: json['description'] as String,
      budgetTotal: (json['budget_total'] as num).toDouble(),
      budgetUtilise: (json['budget_utilise'] as num).toDouble(),
      statut: json['statut'] as String,
      dateDebut: DateTime.parse(json['date_debut'] as String),
      dateFin: json['date_fin'] != null 
          ? DateTime.parse(json['date_fin'] as String)
          : null,
      responsable: json['responsable'] as String?,
      images: (json['images'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList() ?? [],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'commune_id': communeId,
      'titre': titre,
      'description': description,
      'budget_total': budgetTotal,
      'budget_utilise': budgetUtilise,
      'statut': statut,
      'date_debut': dateDebut.toIso8601String(),
      'date_fin': dateFin?.toIso8601String(),
      'responsable': responsable,
      'images': images,
    };
  }

  // Getters calculés
  double get tauxExecution => (budgetUtilise / budgetTotal) * 100;
  double get budgetRestant => budgetTotal - budgetUtilise;
  String get statutLabel {
    switch (statut) {
      case 'en_cours':
        return 'En cours';
      case 'termine':
        return 'Terminé';
      case 'en_attente':
        return 'En attente';
      case 'annule':
        return 'Annulé';
      default:
        return statut;
    }
  }

  String get budgetTotalFormatted {
    final s = budgetTotal.abs().toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  String get budgetUtiliseFormatted {
    final s = budgetUtilise.abs().toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  @override
  String toString() => 'ProjetModel($titre, $statut)';
}
