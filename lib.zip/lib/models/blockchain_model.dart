// lib/models/blockchain_model.dart

/// Modèle d'une transaction financière enregistrée sur la blockchain.
/// Correspond exactement à la réponse de :
/// GET /api/budget/transactions/:commune
class BlockchainTxModel {
  final int id;
  final String commune;
  final String type; // "recette" ou "dépense"
  final String category;
  final int amount; // en FCFA, entier
  final String date; // format "dd/mm/yyyy"
  final int timestamp; // Unix timestamp
  final String description;
  final String recorder; // adresse wallet 0x...
  final String hash; // hash de la transaction blockchain

  BlockchainTxModel({
    required this.id,
    required this.commune,
    required this.type,
    required this.category,
    required this.amount,
    required this.date,
    required this.timestamp,
    required this.description,
    required this.recorder,
    required this.hash,
  });

  factory BlockchainTxModel.fromJson(Map<String, dynamic> j) =>
      BlockchainTxModel(
        id: j['id'] as int,
        commune: j['commune'] as String,
        type: j['type'] as String,
        category: j['category'] as String,
        amount: j['amount'] as int,
        date: j['date'] as String,
        timestamp: j['timestamp'] as int,
        description: j['description'] as String,
        recorder: j['recorder'] as String,
        hash: j['hash'] as String,
      );

  /// true si c'est une recette (argent entrant)
  bool get isRevenue => type == 'recette';

  /// Montant formaté avec séparateurs : 50.000.000
  String get amountFormatted {
    final parts = amount.toString().split('');
    final result = <String>[];
    for (int i = 0; i < parts.length; i++) {
      if (i > 0 && (parts.length - i) % 3 == 0) result.add('.');
      result.add(parts[i]);
    }
    return result.join();
  }

  /// Hash tronqué pour l'affichage : 0xaeba...3da
  String get hashShort {
    if (hash.length < 12) return hash;
    return '${hash.substring(0, 8)}...${hash.substring(hash.length - 3)}';
  }
}

/// Réponse complète de GET /api/budget/balance/:commune
class CommuneBalanceModel {
  final String commune;
  final int balance;
  final String currency;

  CommuneBalanceModel({
    required this.commune,
    required this.balance,
    required this.currency,
  });

  factory CommuneBalanceModel.fromJson(Map<String, dynamic> j) =>
      CommuneBalanceModel(
        commune: j['commune'] as String,
        balance: j['balance'] as int,
        currency: j['currency'] as String,
      );

  String get balanceFormatted {
    final isNeg = balance < 0;
    final parts = balance.abs().toString().split('');
    final result = <String>[];
    for (int i = 0; i < parts.length; i++) {
      if (i > 0 && (parts.length - i) % 3 == 0) result.add('.');
      result.add('.');
    }
    return '${isNeg ? '-' : ''}${result.join()} FCFA';
  }
}
