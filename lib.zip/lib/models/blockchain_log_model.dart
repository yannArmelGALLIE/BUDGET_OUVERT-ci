// lib/models/blockchain_log_model.dart
// Entité BLOCKCHAIN_LOG du MCD — trace immuable d'une transaction

class BlockchainLogModel {
  final String id;
  final String transactionId;
  final String hashBloc;
  final String? hashPrecedent;
  final int numeroBloc;
  final DateTime timestampChain;
  final String? adresseNoeud;
  final String? signatureNumerique;

  const BlockchainLogModel({
    required this.id,
    required this.transactionId,
    required this.hashBloc,
    this.hashPrecedent,
    required this.numeroBloc,
    required this.timestampChain,
    this.adresseNoeud,
    this.signatureNumerique,
  });

  factory BlockchainLogModel.fromJson(Map<String, dynamic> json) {
    return BlockchainLogModel(
      id: json['id_log'] as String? ?? json['id'] as String,
      transactionId: json['id_transaction'] as String,
      hashBloc: json['hash_bloc'] as String,
      hashPrecedent: json['hash_precedent'] as String?,
      numeroBloc: (json['numero_bloc'] as num).toInt(),
      timestampChain: DateTime.parse(json['timestamp_chain'] as String),
      adresseNoeud: json['adresse_noeud'] as String?,
      signatureNumerique: json['signature_numerique'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
        'id_log': id,
        'id_transaction': transactionId,
        'hash_bloc': hashBloc,
        'hash_precedent': hashPrecedent,
        'numero_bloc': numeroBloc,
        'timestamp_chain': timestampChain.toIso8601String(),
        'adresse_noeud': adresseNoeud,
        'signature_numerique': signatureNumerique,
      };

  // Hash tronqué pour affichage
  String get hashCourt =>
      hashBloc.length > 20 ? '${hashBloc.substring(0, 10)}...${hashBloc.substring(hashBloc.length - 10)}' : hashBloc;
}
