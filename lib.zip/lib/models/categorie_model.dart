// lib/models/categorie_model.dart
// Entité CATEGORIE du MCD — classifie les transactions (recettes/dépenses)

import 'package:flutter/material.dart';

class CategorieModel {
  final int id;
  final String libelle;
  final String typeBudget; // 'RECETTE' ou 'DEPENSE'
  final String? icone;      // nom d'icône Material ou URL
  final String? couleurHex; // ex: '#E07B3A'
  final String? description;

  const CategorieModel({
    required this.id,
    required this.libelle,
    required this.typeBudget,
    this.icone,
    this.couleurHex,
    this.description,
  });

  factory CategorieModel.fromJson(Map<String, dynamic> json) {
    return CategorieModel(
      id: json['id_categorie'] as int? ?? json['id'] as int,
      libelle: json['libelle'] as String,
      typeBudget: json['type_budget'] as String? ?? 'DEPENSE',
      icone: json['icone'] as String?,
      couleurHex: json['couleur_hex'] as String?,
      description: json['description'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
        'id_categorie': id,
        'libelle': libelle,
        'type_budget': typeBudget,
        'icone': icone,
        'couleur_hex': couleurHex,
        'description': description,
      };

  bool get isRecette => typeBudget == 'RECETTE';

  // Convertit couleurHex en Color Flutter
  Color get color {
    if (couleurHex == null) {
      return isRecette ? const Color(0xFF2D9B6B) : const Color(0xFFE07B3A);
    }
    final hex = couleurHex!.replaceAll('#', '');
    return Color(int.parse('FF$hex', radix: 16));
  }
}
