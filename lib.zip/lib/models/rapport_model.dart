// lib/models/rapport_model.dart
// Entité RAPPORT du MCD — rapport budgétaire agrégé par période

class RapportModel {
  final String id;
  final String communeId;
  final DateTime periodeDebut;
  final DateTime periodeFin;
  final String typeRapport; // 'mensuel' | 'trimestriel' | 'annuel'
  final double totalRecettes;
  final double totalDepenses;
  final double solde;
  final int nbTransactions;
  final DateTime genereLe;
  final String? urlExport;

  const RapportModel({
    required this.id,
    required this.communeId,
    required this.periodeDebut,
    required this.periodeFin,
    required this.typeRapport,
    required this.totalRecettes,
    required this.totalDepenses,
    required this.solde,
    required this.nbTransactions,
    required this.genereLe,
    this.urlExport,
  });

  factory RapportModel.fromJson(Map<String, dynamic> json) {
    return RapportModel(
      id: json['id_rapport'] as String? ?? json['id'] as String,
      communeId: json['id_commune'] as String,
      periodeDebut: DateTime.parse(json['periode_debut'] as String),
      periodeFin: DateTime.parse(json['periode_fin'] as String),
      typeRapport: json['type_rapport'] as String,
      totalRecettes: (json['total_recettes'] as num).toDouble(),
      totalDepenses: (json['total_depenses'] as num).toDouble(),
      solde: (json['solde'] as num).toDouble(),
      nbTransactions: (json['nb_transactions'] as num).toInt(),
      genereLe: DateTime.parse(json['genere_le'] as String),
      urlExport: json['url_export'] as String?,
    );
  }

  String get periodeLabel {
    final mois = [
      '', 'Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun',
      'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'
    ];
    switch (typeRapport) {
      case 'mensuel':
        return '${mois[periodeDebut.month]} ${periodeDebut.year}';
      case 'trimestriel':
        final t = ((periodeDebut.month - 1) ~/ 3) + 1;
        return 'T$t ${periodeDebut.year}';
      case 'annuel':
        return '${periodeDebut.year}';
      default:
        return '${periodeDebut.day}/${periodeDebut.month}/${periodeDebut.year}';
    }
  }

  String _fmt(double v) {
    final s = v.abs().toInt().toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  String get totalRecettesFormatted => '${_fmt(totalRecettes)} FCFA';
  String get totalDepensesFormatted => '${_fmt(totalDepenses)} FCFA';
  String get soldeFormatted => '${solde >= 0 ? '+' : '-'} ${_fmt(solde)} FCFA';
}
