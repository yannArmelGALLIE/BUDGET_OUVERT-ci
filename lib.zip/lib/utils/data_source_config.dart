// lib/utils/data_source_config.dart
//
// Bascule la transition API REST ↔ démo locale.
// Les données dans `lib/data/statiques_data.dart` sont conservées mais ignorées
// lorsque [kUseStaticDemoData] est `false`.

/// `false` : communes et fiches via [ApiService] ; montants et historique via [BlockchainService].
/// `true` : utilise [StatiquesData] (hors ligne / démo sans backend).
const bool kUseStaticDemoData = false;
