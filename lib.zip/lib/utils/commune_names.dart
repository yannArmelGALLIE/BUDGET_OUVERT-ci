// lib/utils/commune_names.dart
//
// Source unique de vérité pour les communes — 100 % blockchain, zéro API.
//
// Contient :
//   • Le nom exact on-chain (sensible à la casse, identique à recordRevenue/recordExpense)
//   • Les métadonnées statiques (région, département) pour construire CommuneModel
//
// Usage :
//   CommuneNames.toutes()              → List<CommuneModel> (toutes les communes)
//   CommuneNames.communePour('COM-001')→ CommuneModel
//   CommuneNames.nomPour('COM-001')    → 'Commune Abobo'
//   CommuneNames.idPour('Commune Abobo') → 'COM-001'

import '../models/commune_model.dart';

class CommuneNames {
  CommuneNames._();

  // ── Données complètes par commune ─────────────────────────────────────────
  // Chaque entrée : (nomOnChain, departement, region, population)
  // ⚠️  nomOnChain DOIT être identique caractère par caractère à ce qui
  //     a été utilisé dans recordRevenue() / recordExpense() on-chain.
  static const List<_CommuneInfo> _data = [
    _CommuneInfo('COM-001', 'Commune Abobo', 'Abidjan',
        'District Autonome d\'Abidjan', 1200000),
    _CommuneInfo('COM-002', 'Commune Yopougon', 'Abidjan',
        'District Autonome d\'Abidjan', 1800000),
    _CommuneInfo('COM-003', 'Commune Koumassi', 'Abidjan',
        'District Autonome d\'Abidjan', 600000),
    _CommuneInfo('COM-004', 'Commune Marcory', 'Abidjan',
        'District Autonome d\'Abidjan', 350000),
    _CommuneInfo('COM-005', 'Commune Treichville', 'Abidjan',
        'District Autonome d\'Abidjan', 250000),
    _CommuneInfo('COM-006', 'Commune Adjamé', 'Abidjan',
        'District Autonome d\'Abidjan', 400000),
    _CommuneInfo('COM-007', 'Commune Plateau', 'Abidjan',
        'District Autonome d\'Abidjan', 80000),
    _CommuneInfo('COM-008', 'Commune Cocody', 'Abidjan',
        'District Autonome d\'Abidjan', 700000),
    _CommuneInfo('COM-009', 'Commune Attécoubé', 'Abidjan',
        'District Autonome d\'Abidjan', 270000),
    _CommuneInfo('COM-010', 'Commune Port-Bouët', 'Abidjan',
        'District Autonome d\'Abidjan', 310000),
    // TODO : ajouter les autres communes ici
  ];

  // ── Tables de lookup rapide ───────────────────────────────────────────────
  static final Map<String, _CommuneInfo> _byId = {
    for (final c in _data) c.id: c,
  };

  static final Map<String, _CommuneInfo> _byNomOnChain = {
    for (final c in _data) c.nomOnChain: c,
  };

  // ── API publique ──────────────────────────────────────────────────────────

  /// Liste complète des communes sous forme de CommuneModel (sans budget —
  /// les montants viennent de la blockchain via BlockchainService).
  static List<CommuneModel> toutes() => _data.map((c) => c.toModel()).toList();

  /// Retourne le CommuneModel pour un communeId (null si inconnu).
  static CommuneModel? communePour(String communeId) =>
      _byId[communeId]?.toModel();

  /// Retourne le nom exact on-chain pour un communeId.
  /// Lance ArgumentError si l'ID est inconnu.
  static String nomPour(String communeId) {
    final info = _byId[communeId];
    if (info == null) {
      throw ArgumentError(
        'CommuneNames: communeId "$communeId" inconnu. '
        'Ajouter l\'entrée dans commune_names.dart.',
      );
    }
    return info.nomOnChain;
  }

  /// Retourne le communeId pour un nom on-chain (null si absent).
  static String? idPour(String nomOnChain) => _byNomOnChain[nomOnChain]?.id;

  /// Retourne les IDs de toutes les communes connues.
  static List<String> get tousLesIds => _data.map((c) => c.id).toList();

  // Alias rétrocompatibilité avec l'ancien Map idToOnChain
  static Map<String, String> get idToOnChain =>
      {for (final c in _data) c.id: c.nomOnChain};

  static Map<String, String> get onChainToId =>
      {for (final c in _data) c.nomOnChain: c.id};
}

// ── Structure interne ─────────────────────────────────────────────────────
class _CommuneInfo {
  final String id;
  final String nomOnChain;
  final String departement;
  final String region;
  final int? population;

  const _CommuneInfo(this.id, this.nomOnChain, this.departement, this.region,
      [this.population]);

  CommuneModel toModel() => CommuneModel(
        id: id,
        nomCommune: nomOnChain,
        departement: departement,
        region: region,
        population: population,
        statutActif: true,
        // budget et budgetUtilise : null ici, calculés plus tard
        // via BlockchainService.computeStats() après getTransactions()
      );
}
